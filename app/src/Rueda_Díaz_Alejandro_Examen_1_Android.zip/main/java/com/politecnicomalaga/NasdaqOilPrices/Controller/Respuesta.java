package com.politecnicomalaga.NasdaqOilPrices.Controller;


import com.politecnicomalaga.NasdaqOilPrices.Model.Partido;

import org.w3c.dom.Document;
import org.jsoup.Jsoup;
import java.util.LinkedList;
import java.util.List;

/**
 * Clase respuesta. Encapsulará los datos que nos devuelve la API REST
 * opendata de Nasdaq.
 *
 * El controlador le dará el texto a "analizar" en JSON y proporcionará
 * una serialización de los datos "amigable" para la vista. Es en
 * realidad un procesador de textos (parser)
 */

public class Respuesta {
    //ESTADO
    protected String datos;
    //COMPORTAMIENTO
    public Respuesta(String entrada) {
        datos = entrada;
    }


    public List<Partido> getData() {
        LinkedList<Partido> dataList = new LinkedList<>();
        // Parsing the HTML

        String parsear = encontrarMetaDescription(datos);
        //buscamos meta name="description"
        //analizamos toda la información
        int inicio = parsear.indexOf("los siguientes: ");
        int fin = parsear.indexOf("El reparto");

        parsear=parsear.substring(inicio,fin);
        String[] Depurar=parsear.split();
        for(String temp : Depurar){ //numero - Equipo1 - "-" - Equipo2 - Resultado

        }

        return dataList;

    }
    private String encontrarMetaDescription(String html) {
        String[] lines = html.split("\n");
        for (String line : lines) {
            if (line.contains("<meta name=\"description\"")) {
                return line;
            }
        }
        return null;
    }
}
